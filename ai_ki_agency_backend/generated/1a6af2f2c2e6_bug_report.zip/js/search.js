// search.js
(() => {
  const API_ENDPOINT = 'https://yourdomain.com/api/search';
  const input = document.getElementById('search-input');
  const button = document.getElementById('search-button');
  const resultsContainer = document.getElementById('search-results');
  const DEBOUNCE_DELAY = 300;

  let debounceTimer = null;

  const setLoading = (isLoading) => {
    resultsContainer.innerHTML = isLoading ? '<div class="loading">Loading...</div>' : '';
  };

  const renderError = (msg) => {
    resultsContainer.innerHTML = `<div class="error">${msg}</div>`;
  };

  const renderNoResults = () => {
    resultsContainer.innerHTML = '<div class="no-results">No results found.</div>';
  };

  const renderResults = (items) => {
    if (!items || items.length === 0) {
      renderNoResults();
      return;
    }
    const ul = document.createElement('ul');
    items.forEach(item => {
      const li = document.createElement('li');
      li.className = 'result-item';
      li.textContent = item.text || item;
      ul.appendChild(li);
    });
    resultsContainer.innerHTML = '';
    resultsContainer.appendChild(ul);
  };

  const fetchResults = async (query) => {
    setLoading(true);
    try {
      const url = `${API_ENDPOINT}?q=${encodeURIComponent(query)}`;
      const response = await fetch(url);
      if (!response.ok) throw new Error('Network response was not ok');
      const data = await response.json();
      renderResults(data.results || data);
    } catch (err) {
      renderError('Error fetching results. Please try again.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const validateAndSearch = () => {
    const query = input.value.trim();
    if (!query) {
      renderError('Please enter a search term.');
      return;
    }
    if (query.length > 200) {
      renderError('Search term is too long.');
      return;
    }
    fetchResults(query);
  };

  const debouncedSearch = () => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(validateAndSearch, DEBOUNCE_DELAY);
  };

  // Event listeners
  input.addEventListener('input', debouncedSearch);
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      clearTimeout(debounceTimer);
      validateAndSearch();
    }
  });
  button.addEventListener('click', (e) => {
    e.preventDefault();
    clearTimeout(debounceTimer);
    validateAndSearch();
  });
})();